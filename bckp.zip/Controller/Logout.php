<?php

require_once 'AdminController.php';

$adminController = new AdminController();
$adminController->logout();
