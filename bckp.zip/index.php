<?php
declare(strict_types=1);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'Router.php';

$router = new Router($_GET['path']);

$router->addRoute('upload', 'Controller/UploadController');
$router->addRoute('show', 'Controller/ShowController');
$router->addRoute('admin', 'Controller/AdminController');
$router->addRoute('logout', 'Controller/AdminController', 'logout');
$router->addRoute('login', 'Controller/AdminController', 'handleLogin');

$router->dispatch();
